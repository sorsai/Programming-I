import java.util.*;

public class MultiplicationTable {
	public static void main(String[] args) {
		Scanner multi = new Scanner(System.in);
		System.out.print("Please enter the number:  ");
		int number = multi.nextInt();
		
		for (int x = 1 ; x <=12 ; x++ ){
		int sum = number*x;
		System.out.println( number + "x" + x + ": " + sum );
		}
		
	}
}
