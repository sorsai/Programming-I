import java.util.Scanner;

public class MultiplicationTable2 {
	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);

		System.out.print("Please enter first number: ");
		int number = console.nextInt();

		System.out.print("Please enter second number: ");
		int number2 = console.nextInt();

		if (number > number2) {
			System.out.println("Cannot create multiplication table.");
		} else {
			for (int x = number; x <= number2; x++) {
				for (int j = 1; j <= 12; j++) {
					int sum = x*j;
					System.out.println(x + "x" + j + ": " + sum);
				}
			}
		}
	}
}
